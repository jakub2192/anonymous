import os
import io
import json
import threading
import traceback
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
from yawsp import get_url, _handle, _addon


_addon = xbmcaddon.Addon()
try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

_profile = translatePath(_addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except Exception:
    pass


def _ensure_profile_dir(path):
    """
    Ensure Kodi profile directory exists before reading/writing json.
    Prefer xbmcvfs (works with special://) and fall back to os.makedirs.
    """
    try:
        import xbmcvfs

        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)
        return
    except Exception:
        pass

    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        traceback.print_exc()


_ensure_profile_dir(_profile)

LOCAL_HISTORY_FILE = os.path.join(_profile, 'local_history.json')
LOCAL_HISTORY_LOCK = threading.Lock()
MAX_HISTORY_FILE_SIZE = 15 * 1024 * 1024  # 15 MB

def load_local_history():
    try:
        with LOCAL_HISTORY_LOCK:
            if not os.path.exists(LOCAL_HISTORY_FILE):
                return []
            with io.open(LOCAL_HISTORY_FILE, 'r', encoding='utf8') as f:
                try:
                    data = json.load(f)
                    return data
                except Exception as e:
                    xbmc.log("Exception loading history: {}".format(e), xbmc.LOGERROR)
                    return []
    except Exception as e:
        traceback.print_exc()
        return []

def save_local_history(history):
    try:
        with LOCAL_HISTORY_LOCK:
            # Ensure file size does not exceed 10MB
            trimmed = False
            while True:
                data = json.dumps(history, ensure_ascii=False, indent=2)
                size = len(data.encode('utf-8'))
                if size <= MAX_HISTORY_FILE_SIZE:
                    break
                if history:
                    history.pop(-1)
                    trimmed = True
                else:
                    break
            if trimmed:
                xbmc.log("History trimmed to fit 15MB limit.", xbmc.LOGERROR)
            with io.open(LOCAL_HISTORY_FILE, 'w', encoding='utf8') as f:
                f.write(data)
    except Exception as e:
        traceback.print_exc()

def add_to_local_history(item, finished):
    history = load_local_history()
    # Find previous entry if exists
    prev = next((h for h in history if h.get('ident') == item.get('ident')), None)
    # Remove duplicate by ident if exists
    history = [h for h in history if h.get('ident') != item.get('ident')]
    # If unfinished, keep max progress/duration
    if prev and not finished:
        item['progress'] = max(item.get('progress', 0), prev.get('progress', 0))
        item['duration'] = max(item.get('duration', 0), prev.get('duration', 0))
        item['finished'] = False
    else:
        item['finished'] = finished
    history.insert(0, item)
    # Limit history size (optional, e.g. 100)
    history = history[:100]
    save_local_history(history)

def _hms(seconds):
    try:
        seconds = int(float(seconds))
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        return f"{h:02}:{m:02}:{s:02}"
    except Exception:
        return "00:00:00"

def history(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30203))
    updateListing = False

    # Remove entry if requested
    if 'remove' in params:
        history_list = load_local_history()
        history_list = [h for h in history_list if h.get('ident') != params['remove']]
        save_local_history(history_list)
        updateListing = True

    def is_finished(item):
        try:
            return (
                float(item.get('duration', 0)) > 0 and
                float(item.get('progress', 0)) / float(item.get('duration', 1)) >= 0.9
            )
        except Exception:
            return False

    from yawsp import tolistitem, get_url  # Import here to avoid circular import
    history_list = [h for h in load_local_history() if is_finished(h)]
    for item in history_list:
        commands = []
        commands.append((_addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history', remove=str(item.get('ident', ''))) + ')'))
        commands.append((_addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history', toqueue=str(item.get('ident', ''))) + ')'))
        label = item.get('name', '')
        if 'duration' in item and 'progress' in item:
            label += f" ({_hms(item['progress'])}/{_hms(item['duration'])})"
        item_for_list = dict(item)
        item_for_list['name'] = label
        item_for_list['ident'] = str(item_for_list.get('ident', ''))
        listitem = tolistitem(item_for_list, commands)
        play_params = {
            'action': 'play',
            'ident': str(item.get('ident', '')),
            'name': item.get('name', '')
        }
        xbmcplugin.addDirectoryItem(
            _handle,
            get_url(**play_params),
            listitem,
            False
        )

    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def unfinished(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ Rozpozerane streamy")
    updateListing = False

    if 'remove' in params:
        history_list = load_local_history()
        history_list = [h for h in history_list if h.get('ident') != params['remove']]
        save_local_history(history_list)
        updateListing = True

    from yawsp import tolistitem, get_url  # Import here to avoid circular import
    unfinished_list = [h for h in load_local_history() if not h.get('finished', False) and h.get('progress', 0) > 0]
    for item in unfinished_list:
        commands = []
        commands.append(("Remove", 'Container.Update(' + get_url(action='unfinished', remove=str(item.get('ident', ''))) + ')'))
        label = item.get('name', '')
        if 'duration' in item and 'progress' in item:
            label += f" ({_hms(item['progress'])}/{_hms(item['duration'])})"
        item_for_list = dict(item)
        item_for_list['name'] = label
        item_for_list['ident'] = str(item_for_list.get('ident', ''))
        listitem = tolistitem(item_for_list, commands)
        play_params = {
            'action': 'play',
            'ident': str(item.get('ident', '')),
            'name': item.get('name', '')
        }
        xbmcplugin.addDirectoryItem(
            _handle,
            get_url(**play_params),
            listitem,
            False
        )

    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)
