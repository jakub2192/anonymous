from yawsp import get_url, _handle, _addon, get, headers, ask
import xbmcgui
import xbmc
import xbmcplugin
from bs4 import BeautifulSoup
import re

CSFD_SEARCH_SERIES = '//www.csfd.cz/hledat/?pageSeries=3&films=0&users=0&creators=0&q={series_name}'


def render_csfd_series():
    series_list = get_csfd_series()
    if not series_list:
        xbmcgui.Dialog().notification("CSFD Series", "No Series found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    for serie in series_list:

        if not serie['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=serie['movie'] + ' ' + serie['genre'])
            if serie['img'] is not None:
                listitem.setArt({'thumb': serie['img'],
                                 'icon': serie['img'],
                                 'poster': serie['img'],
                                 'fanart': serie['img']})
            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action='episodes', what=serie['href'], serie=serie['serie'], img=serie.get('img', '')),
                listitem,
                True
            )
    xbmcplugin.endOfDirectory(_handle)

def episodes(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')

    episodes = []
    div = soup.find('div', class_='film-episodes-list')
    img = params.get('img', None)
    if div:
        for li in div.find_all('li'):
            h3 = li.find('h3', class_='film-title-inline')
            if not h3:
                continue
            a = h3.find('a', class_='film-title-name')
            info_span = h3.find('span', class_='film-title-info')
            year = info_span.find('span', class_='info').text if info_span and info_span.find('span', class_='info') else ''
            episode_count = re.sub(r'^\s*\d{4}\D*', '', info_span.text).strip()
            episodes.append({
                'title': a.text if a else '',
                'href': a['href'] if a else '',
                'info': info_span.text if info_span else '',
                'year': year,
                'episode_count': episode_count,
                'serie': params['serie'],
                'img': img
            })
    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=f"{episode['title']} {episode['year']} {episode['episode_count']}")
        if episode.get('img'):
            listitem.setArt({'thumb': episode['img'],
                             'icon': episode['img'],
                             'poster': episode['img'],
                             'fanart': episode['img']})
        if re.search(r'\(E\d+\)', episode['info']):
            xbmcplugin.addDirectoryItem(_handle,get_url(action='search', what=episode['serie']),listitem,True)
        else:
            xbmcplugin.addDirectoryItem(_handle,get_url(action='episodeinseries', what=episode['href'], year=episode['year'], serie=params['serie']),listitem,True )
    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)



def episodeinseries(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('h3', class_="film-title")

    episodes = []
    div = soup.find('div', class_='film-episodes-list')
    if div:
     for li in div.find_all('li'):
        h3 = li.find('h3', class_='film-title-inline')
        if not h3:
            continue
        a = h3.find('a', class_='film-title-name')
        info = h3.find('span', class_='film-title-info')
        episodes.append({
            'title': a.text  + ' ' + params['year'] if a else '',
            'href': a['href'] if a else '',
            'info': info.text if info else '',
            'serie': params['serie'] + ' '  + info.text
        })

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=episode['title'] + ' ' + episode['info'])
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['serie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def get_csfd_series():
    """Get daily tips from CSFD site."""
    data_url = CSFD_SEARCH_SERIES
    search_value = ask('')
    if search_value is None:
        return []
    result = get(data_url.format(series_name=search_value), headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article article-poster-50")
    return [
        {
            "href": elem.find('a')['href'],
            "img": None if elem.find('img', class_='empty-image')  else 'https:' + elem.find('img')['src'],
            "serie": elem.find('p', class_="search-name").text if elem.find('p', class_="search-name") else elem.find('a', class_="film-title-name").text,
            "movie": f"{elem.find('a', class_='film-title-name').text} {elem.find('span', class_='info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        }
        for elem in main
        if elem.find('span', class_='film-title-info') and '(seriál)' in elem.find('span', class_='film-title-info').text
    ]
