from enum import Enum


class CsfdGenre(Enum):
    # value = (genre_id_from_csfd, static_string)
    ACTION = ("1", "Akční / Action")
    COMEDY = ("2", "Komedie / Comedy")
    DRAMA = ("3", "Drama")
    HORROR = ("4", "Horor")
    # ... add all needed genres here

    @property
    def id(self) -> str:
        return self.value[0]

    @property
    def label(self) -> str:
        return self.value[1]

    @classmethod
    def from_id(cls, genre_id: str) -> "CsfdGenre | None":
        for g in cls:
            if g.id == str(genre_id):
                return g
        return None
