from yawsp import requests
import xbmcgui

GITHUB_VERSION_URL = "https://jakub2192.github.io/anonymous/docs/"

def get_latest_version():
    try:
        response = requests.get(GITHUB_VERSION_URL + "version.txt", timeout=10)
        if response.status_code == 200:
            return response.text.strip()
    except Exception:
        pass
    return None

def is_new_version_available(current_version):
    latest = get_latest_version()
    if latest is None:
        return False
    # Simple version comparison, assumes semantic versioning
    def version_tuple(v):
        return tuple(map(int, (v.split("."))))
    try:
        return version_tuple(latest) > version_tuple(current_version)
    except Exception:
        return False


def check_and_notify(current_version):
    latest = get_latest_version()
    if latest and is_new_version_available(current_version):
        # Fetch changelog
        changelog = ""
        try:
            import requests
            changelog_url = GITHUB_VERSION_URL + "changelog.txt"
            response = requests.get(changelog_url, timeout=10)
            if response.status_code == 200:
                changelog = response.text.strip()
        except Exception:
            changelog = ""
        # Show notification
        xbmcgui.Dialog().notification(
            "Plugin Update",
            f"New version available!\nCurrent: {current_version}\nLatest: {latest}",
            xbmcgui.NOTIFICATION_INFO,
            5000
        )
        # Show changelog in a dialog if available
        if changelog:
            xbmcgui.Dialog().textviewer("Changelog", changelog)
