from yawsp import get_url, _handle, _addon, get, headers, ask
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
import re

CSFD_SEARCH_SERIES = '//www.csfd.cz/hledat/?pageSeries=3&films=0&users=0&creators=0&q={series_name}'


def render_csfd_series():
    series_list = get_csfd_series()
    if not series_list:
        xbmcgui.Dialog().notification("CSFD Series", "No Series found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    for serie in series_list:
        if not serie['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=serie['movie'] + ' ' + serie['genre'])
            xbmcplugin.addDirectoryItem(_handle, get_url(action='episodes', what=serie['href'], serie=serie['serie']), listitem, True)
    xbmcplugin.endOfDirectory(_handle)

def episodes(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('h3', class_="film-title")
    episodes = []
    for season in main:
        serie = params['serie'] + ' '  + season.find('span', class_="film-title-info").text
        year = season.find('span', class_="info").text
        title = season.find('a').text
        info = season.find('span', class_="film-title-info").text
        href = season.find('a')['href']
        episodes.append({'title': title, 'href': href, 'info': info, 'year': year, 'serie': serie})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=episode['title'] + ' ' + episode['info'])
        if re.search(r'\(E\d+\)', episode['info']):
            xbmcplugin.addDirectoryItem(_handle,get_url(action='search', what=episode['serie']),listitem,True)
        else:
            xbmcplugin.addDirectoryItem(_handle,get_url(action='episodeinseries', what=episode['href'], year=episode['year'], serie=params['serie']),listitem,True )
    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)



def episodeinseries(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('h3', class_="film-title")
    episodes = []
    for season in main:
        serie = params['serie'] + ' '  + season.find('span', class_="film-title-info").text
        title = season.find('a').text + ' ' + params['year']
        info = season.find('span', class_="film-title-info").text
        href = season.find('a')['href']
        episodes.append({'title': title, 'href': href, 'info': info, 'serie': serie})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=episode['title'] + ' ' + episode['info'])
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['serie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def get_csfd_series():
    """Get daily tips from CSFD site."""
    data_url = CSFD_SEARCH_SERIES
    search_value = ask('')
    if search_value is None:
        return []
    result = get(data_url.format(series_name=search_value), headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('div', class_="article-content")
    return [
        {
            "href": elem.find('a')['href'],
            "serie": elem.find('p', class_="search-name").text if elem.find('p', class_="search-name") else elem.find('a').text,
            "movie": f"{elem.find('a').text} {elem.find('span', class_='film-title-info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        }
        for elem in main
        if elem.find('span', class_='film-title-info') and '(seriál)' in elem.find('span', class_='film-title-info').text
    ]
