from yawsp import get_url, _handle, _addon, ask, get, CSFD_URL, headers
import xbmcgui
import xbmcplugin
import xbmc
from bs4 import BeautifulSoup


CSFD_SEARCH_MOVIE = '//www.csfd.cz/hledat/?pageFilms=3&series=0&users=0&creators=0&q={movie_name}'


def render_csfd_movies():
    movie_list = get_csfd_movies()
    if not movie_list:
        xbmcgui.Dialog().notification("CSFD Movies", "No movies found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    for movie in movie_list:
        if not movie['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=movie['movie'] + ' ' + movie['genre'])
            if movie['img'] is not None:
                xbmc.log(movie['img'], xbmc.LOGERROR)
                listitem.setArt({'thumb': movie['img'],
                                 'icon': movie['img'],
                                 'poster': movie['img'],
                                 'fanart': movie['img']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=movie['movie']), listitem, True)
    xbmcplugin.endOfDirectory(_handle)

def get_csfd_movies():
    """Get daily tips from CSFD site."""
    data_url = CSFD_SEARCH_MOVIE
    search_value = ask('')
    if search_value is None:
        return

    result = get(data_url.format(movie_name=search_value), headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article article-poster-50")
    print("CSFD Movies Search Result:")
    print(main)
    #return [f"{elem.find('a').text} {elem.find('span', class_='info').text} {elem.find('p', class_='film-origins-genres').find('span', class_='info').text}" for elem in main]
    return [
        {   "img": None if elem.find('img', class_='empty-image')  else 'https:' + elem.find('img')['src'],
            "movie": f"{elem.find('a', class_='film-title-name').text} {elem.find('span', class_='info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
            }
        for elem in main
    ]


def render_movie_section():
    listitem = xbmcgui.ListItem(label='Vyhladavanie filmu')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='render_csfd_movies'), listitem, True)

    listitem = xbmcgui.ListItem(label='Najlepsie filmy z CSFD')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='render_rank_movies'), listitem, True)

    listitem = xbmcgui.ListItem(label='Zanre filmov')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='Genres'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)


def render_rank_movies():
    listitem = xbmcgui.ListItem(label='0-99')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi'), listitem, True)

    listitem = xbmcgui.ListItem(label='100-199')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=100'), listitem, True)

    listitem = xbmcgui.ListItem(label='200-299')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=200'), listitem, True)

    listitem = xbmcgui.ListItem(label='300-399')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=300'), listitem, True)

    listitem = xbmcgui.ListItem(label='400-499')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=400'), listitem, True)

    listitem = xbmcgui.ListItem(label='500-599')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=500'), listitem, True)

    listitem = xbmcgui.ListItem(label='600-699')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=600'), listitem, True)

    listitem = xbmcgui.ListItem(label='700-799')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=700'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)

def get_rank_movies(params):
    # Get the list of movies from the get_csfd_tips function

    result = get(CSFD_URL + params['ask'], headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article")
    episodes = []
    for season in main:
        img = None if season.find('img', class_='empty-image')  else 'https:' + season.find('img')['src']
        title = season.find('a', class_='film-title-name').text.strip() + ' ' + season.find('span', class_="film-title-info").text.strip() + ' Rating: ' + season.find('div', class_="rating-average").text.strip()
        href = season.find('a', class_='film-title-name')['href']
        genre = season.find('p', class_='film-origins-genres').find('span', class_='info').text.strip()
        isadult = True if 'Pornografický' in season.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in season.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        episodes.append({'title': title, 'href': href, 'img': img, 'isadult': isadult, 'genre': genre})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        if not episode['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=episode['title'] )
            if episode['img'] is not None:
                listitem.setArt({'thumb': episode['img'],
                                 'icon': episode['img'],
                                 'poster': episode['img'],
                                 'fanart': episode['img']})
                listitem.setInfo('video', {'plot': episode['title'] + '\n' +
                                                   episode['genre']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['title']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)

