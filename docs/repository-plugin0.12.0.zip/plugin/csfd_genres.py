import xbmcgui
import xbmcplugin

from yawsp import get, get_url, _handle, headers


CSFD_GENRES = '//www.csfd.cz/zebricky/vlastni-vyber/'


def get_csfd_genres():
    """CSFD: fetch genres list and return [{id,name}, ...]."""
    result = get(CSFD_GENRES, headers=headers, timeout=20)
    soup = __import__('bs4').BeautifulSoup(result.content, 'html.parser')

    genres = []
    for block in soup.find_all('div', class_='genres-content'):
        inputs = block.find_all('input')
        spans = block.find_all('span')
        for inp, span in zip(inputs, spans):
            genre_id = inp.get('value')
            name = span.get_text(strip=True)
            if genre_id and name:
                genres.append({'id': genre_id, 'name': name})
    return genres

def render_csfd_genres():
    genre_list = get_csfd_genres()
    if not genre_list:
        xbmcgui.Dialog().notification('CSFD Genres', 'No genres found.', xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for genre in genre_list:
        label = genre['name'] if isinstance(genre['name'], str) else str(genre['name'])
        genre_id = genre['id']
        listitem = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(
            _handle,
            get_url(action='search', what=label, genre_id=genre_id),
            listitem,
            True
        )

    xbmcplugin.endOfDirectory(_handle)
