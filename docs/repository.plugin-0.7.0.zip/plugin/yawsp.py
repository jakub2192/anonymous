# -*- coding: utf-8 -*-
# Module: default
# Author: cache-sk
# Created on: 10.5.2020
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import io
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests.cookies
from xml.etree import ElementTree as ET
import hashlib
from md5crypt import md5crypt
from bs4 import BeautifulSoup
import traceback
import json
import unidecode
import re
import zipfile
import uuid
import time
import threading


try:
    from urllib import urlencode
    from urlparse import parse_qsl, urlparse
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl, urlparse

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'
CATEGORIES = ['','video','images','audio','archives','docs','adult']
SORTS = ['','recent','rating','largest','smallest']
SEARCH_HISTORY = 'search_history'
NONE_WHAT = '%#NONE#%'
BACKUP_DB = 'D1iIcURxlR'
CSFD_TIPS = '//csfd.cz/televize'
CSFD_URL = '//www.csfd.cz'
CSFD_GENRES = '//csfd.cz/zebricky/vlastni-vyber/'
CSFD_SEARCH_MOVIE = '//www.csfd.cz/hledat/?pageFilms=3&series=0&users=0&creators=0&q={movie_name}'
CSFD_SEARCH_SERIES = '//www.csfd.cz/hledat/?pageSeries=3&films=0&users=0&creators=0&q={series_name}'


headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:75.0) Gecko/20100101 Firefox/75.0',
}

class HTTP_METHOD:
    GET = 'get'
    POST = 'post'
    HEAD = 'head'

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)
_profile = translatePath( _addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except:
    pass

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def api(fnct, data):
    response = _session.post(API + fnct + "/", data=data)
    return response

def is_ok(xml):
    status = xml.find('status').text
    return status == 'OK'

def popinfo(message, heading=_addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False): #NOTIFICATION_WARNING NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def login():
    username = _addon.getSetting('wsuser')
    password = _addon.getSetting('wspass')
    if username == '' or password == '':
        popinfo(_addon.getLocalizedString(30101), sound=True)
        _addon.openSettings()
        return
    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        salt = xml.find('salt').text
        try:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
        except TypeError:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()
        response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            token = xml.find('token').text
            _addon.setSetting('token', token)
            return token
        else:
            popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            _addon.openSettings()
    else:
        popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        _addon.openSettings()

def revalidate():
    token = _addon.getSetting('token')
    if len(token) == 0:
        if login():
            return revalidate()
    else:
        response = api('user_data', { 'wst': token })
        xml = ET.fromstring(response.content)
        status = xml.find('status').text
        if is_ok(xml):
            vip = xml.find('vip').text
            if vip != '1':
                popinfo(_addon.getLocalizedString(30103), icon=xbmcgui.NOTIFICATION_WARNING)
            return token
        else:
            if login():
                return revalidate()

def todict(xml, skip=[]):
    result = {}
    for e in xml:
        if e.tag not in skip:
            value = e.text if len(list(e)) == 0 else todict(e,skip)
            if e.tag in result:
                if isinstance(result[e.tag], list):
                    result[e.tag].append(value)
                else:
                    result[e.tag] = [result[e.tag],value]
            else:
                result[e.tag] = value
    #result = {e.tag:(e.text if len(list(e)) == 0 else todict(e,skip)) for e in xml if e.tag not in skip}
    return result
            
def sizelize(txtsize, units=['B','KB','MB','GB']):
    if txtsize:
        size = float(txtsize)
        if size < 1024:
            size = str(size) + units[0]
        else:
            size = size / 1024
            if size < 1024:
                size = str(int(round(size))) + units[1]
            else:
                size = size / 1024
                if size < 1024:
                    size = str(round(size,2)) + units[2]
                else:
                    size = size / 1024
                    size = str(round(size,2)) + units[3]
        return size
    return str(txtsize)
    
def labelize(file):
    if 'size' in file:
        size = sizelize(file['size'])
    elif 'sizelized' in file:
        size = file['sizelized']
    else:
        size = '?'
    label = file['name'] + ' (' + size + ')'
    return label
    
def tolistitem(file, addcommands=[]):
    label = labelize(file)
    listitem = xbmcgui.ListItem(label=label)
    if 'img' in file:
        listitem.setArt({'thumb': file['img'],
                         'icon': file['img'],
                         'poster': file['img'],
                         'fanart': file['img']})
    listitem.setInfo('video', {'title': label})
    listitem.setProperty('IsPlayable', 'true')
    commands = []
    commands.append(( _addon.getLocalizedString(30211), 'RunPlugin(' + get_url(action='info',ident=file['ident']) + ')'))
    commands.append(( _addon.getLocalizedString(30212), 'RunPlugin(' + get_url(action='download',ident=file['ident']) + ')'))
    if addcommands:
        commands = commands + addcommands
    listitem.addContextMenuItems(commands)
    return listitem

def ask(what):
    if what is None:
        what = ''
    kb = xbmc.Keyboard(what, _addon.getLocalizedString(30007))
    kb.doModal() # Onscreen keyboard appears
    if kb.isConfirmed():
        return kb.getText() # User input
    return None
    
def loadsearch():
    history = []
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)
    except Exception as e:
        traceback.print_exc()
    
    try:
        with io.open(os.path.join(_profile, SEARCH_HISTORY), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                history = json.loads(fdata, "utf-8")
            except TypeError:
                history = json.loads(fdata)
    except Exception as e:
        traceback.print_exc()

    return history


def storesearch(what):
    if what:
        size = int(_addon.getSetting('shistory'))

        history = loadsearch()

        if what in history:
            history.remove(what)

        history = [what] + history
        
        if len(history)>size:
            history = history[:size]

        try:
            with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(history).decode('utf8')
                except AttributeError:
                    data = json.dumps(history)
                file.write(data)
                file.close()
        except Exception as e:
            traceback.print_exc()

def removesearch(what):
    if what:
        history = loadsearch()
        if what in history:
            history.remove(what)
            try:
                with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                    try:
                        data = json.dumps(history).decode('utf8')
                    except AttributeError:
                        data = json.dumps(history)
                    file.write(data)
                    file.close()
            except Exception as e:
                traceback.print_exc()



INFO_CACHE_FILE = os.path.join(_profile, 'info_cache.json')
INFO_LOCK = threading.Lock()

def load_info_cache():
    try:
        with INFO_LOCK:
            if not os.path.exists(INFO_CACHE_FILE):
                return {}
            with io.open(INFO_CACHE_FILE, 'r', encoding='utf8') as f:
                try:
                    return json.load(f)
                except TypeError:
                    return json.loads(f.read())
    except Exception:
        traceback.print_exc()
        return {}

MAX_INFO_CACHE_SIZE = 500
def save_info_cache(cache):
    try:
        with INFO_LOCK:
            # shrink cache if too large (keep latest keys)
            if len(cache) > MAX_INFO_CACHE_SIZE:
                # convert to list to preserve insertion order (Py3.7+)
                keys = list(cache.keys())
                for k in keys[0:len(cache) - MAX_INFO_CACHE_SIZE]:
                    cache.pop(k, None)

            with io.open(INFO_CACHE_FILE, 'w', encoding='utf8') as f:
                try:
                    data = json.dumps(cache).decode('utf8')
                except AttributeError:
                    data = json.dumps(cache)
                f.write(data)
    except Exception:
        traceback.print_exc()


def _background_fetch_info(idents, action, what, category, sort, limit, offset):
    cache = load_info_cache()
    updated = False

    for ident in idents:
        if ident in cache:
            continue
        try:
            # `info` returns a string with plot
            plot = info({'ident': ident})
            if plot:
                cache[ident] = plot
                updated = True
        except Exception:
            traceback.print_exc()

    if updated:
        save_info_cache(cache)
        # force container reload on main thread by updating URL (same params)
        xbmc.executebuiltin(
            'Container.Update({0})'.format(
                get_url(
                    action=action,
                    what=what,
                    category=category,
                    sort=sort,
                    limit=limit,
                    offset=offset
                )
            )
        )



def dosearch(token, what, category, sort, limit, offset, action):
    response = api('search', {
        'what': '' if what == NONE_WHAT else what,
        'category': category,
        'sort': sort,
        'limit': limit,
        'offset': offset,
        'wst': token,
        'maybe_removed': 'true'
    })
    xml = ET.fromstring(response.content)
    if is_ok(xml):

        if offset > 0:  # prev page
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30206))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action=action, what=what, category=category, sort=sort,
                        limit=limit, offset=offset - limit if offset > limit else 0),
                listitem,
                True
            )

        cache = load_info_cache()
        missing_idents = []

        for file in xml.iter('file'):
            item = todict(file)
            commands = []
            commands.append((_addon.getLocalizedString(30214),
                             'Container.Update(' + get_url(action='search',
                                                           toqueue=item['ident'],
                                                           what=what,
                                                           offset=offset) + ')'))
            listitem = tolistitem(item, commands)
            listitem.setProperty('need_update', 'true')

            ident = item['ident']
            if ident in cache:
                listitem.setInfo('video', {'plot': cache[ident]})
            else:
                # temporary minimal plot
                listitem.setInfo('video', {'plot': item.get('name', '')})
                missing_idents.append(ident)

            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action='play', ident=item['ident'], name=item['name']),
                listitem,
                False
            )

        try:
            total = int(xml.find('total').text)
        except:
            total = 0

        if offset + limit < total:  # next page
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30207))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action=action, what=what, category=category, sort=sort,
                        limit=limit, offset=offset + limit),
                listitem,
                True
            )

        # start background thread for missing info
        if missing_idents:
            t = threading.Thread(
                target=_background_fetch_info,
                args=(missing_idents, action, what, category, sort, limit, offset)
            )
            t.daemon = True
            t.start()

    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

def search(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30201))
    token = revalidate()
    
    updateListing=False
    
    if 'remove' in params:
        removesearch(params['remove'])
        updateListing=True
        
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    what = None
    
    if 'what' in params:
        what = params['what']

    
    if 'ask' in params:
        slast = _addon.getSetting('slast')
        if slast != what:
            what = ask(what)
            if what is not None:
                storesearch(what)
            else:
                updateListing=True

    if what is not None:
        if 'offset' not in params:
            _addon.setSetting('slast',what)
        else:
            _addon.setSetting('slast',NONE_WHAT)
            updateListing=True
        
        category = params['category'] if 'category' in params else CATEGORIES[int(_addon.getSetting('scategory'))]
        sort = params['sort'] if 'sort' in params else SORTS[int(_addon.getSetting('ssort'))]
        limit = int(params['limit']) if 'limit' in params else int(_addon.getSetting('slimit'))
        offset = int(params['offset']) if 'offset' in params else 0
        dosearch(token, what, category, sort, limit, offset, 'search')
    else:
        _addon.setSetting('slast',NONE_WHAT)
        history = loadsearch()
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
        listitem.setArt({'icon': 'DefaultAddSource.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)
        
        #newest
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
        listitem.setArt({'icon': 'DefaultAddonsRecentlyUpdated.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)
        
        #biggest
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
        listitem.setArt({'icon': 'DefaultHardDisk.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)
        
        for search in history:
            listitem = xbmcgui.ListItem(label=search)
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search) + ')'))
            listitem.addContextMenuItems(commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search,ask=1), listitem, True)
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def render_csfd_genres():
    movie_list = get_csfd_genres()

    # Check if the list is empty
    if not movie_list:
        xbmcgui.Dialog().notification("CSFD Genres", "No movies found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for movie in movie_list:
        listitem = xbmcgui.ListItem(label=movie)
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=movie), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def render_csfd_movies():
    # Get the list of movies from the get_csfd_tips function
    movie_list = get_csfd_movies()

    # Check if the list is empty
    if not movie_list:
        xbmcgui.Dialog().notification("CSFD Movies", "No movies found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for movie in movie_list:
        if not movie['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=movie['movie'] + ' ' + movie['genre'])
            if movie['img'] is not None:
                xbmc.log(movie['img'], xbmc.LOGERROR)
                listitem.setArt({'thumb': movie['img'],
                                 'icon': movie['img'],
                                 'poster': movie['img'],
                                 'fanart': movie['img']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=movie['movie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def render_movie_section():
    listitem = xbmcgui.ListItem(label='Vyhladavanie filmu')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='render_csfd_movies'), listitem, True)

    listitem = xbmcgui.ListItem(label='Najlepsie filmy z CSFD')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='render_rank_movies'), listitem, True)

    listitem = xbmcgui.ListItem(label='Zanre filmov')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='Genres'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)


def render_rank_movies():
    listitem = xbmcgui.ListItem(label='0-99')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi'), listitem, True)

    listitem = xbmcgui.ListItem(label='100-199')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=100'), listitem, True)

    listitem = xbmcgui.ListItem(label='200-299')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=200'), listitem, True)

    listitem = xbmcgui.ListItem(label='300-399')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=300'), listitem, True)

    listitem = xbmcgui.ListItem(label='400-499')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=400'), listitem, True)

    listitem = xbmcgui.ListItem(label='500-599')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=500'), listitem, True)

    listitem = xbmcgui.ListItem(label='600-699')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=600'), listitem, True)

    listitem = xbmcgui.ListItem(label='700-799')
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='get_rank_movies',ask='/zebricky/filmy/nejlepsi/?from=700'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)

def get_rank_movies(params):
    # Get the list of movies from the get_csfd_tips function

    result = get(CSFD_URL + params['ask'], headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article")
    episodes = []
    for season in main:
        img = None if season.find('img', class_='empty-image')  else 'https:' + season.find('img')['src']
        title = season.find('a', class_='film-title-name').text.strip() + ' ' + season.find('span', class_="film-title-info").text.strip() + ' Rating: ' + season.find('div', class_="rating-average").text.strip()
        href = season.find('a', class_='film-title-name')['href']
        genre = season.find('p', class_='film-origins-genres').find('span', class_='info').text.strip()
        isadult = True if 'Pornografický' in season.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in season.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        episodes.append({'title': title, 'href': href, 'img': img, 'isadult': isadult, 'genre': genre})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        if not episode['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=episode['title'] )
            if episode['img'] is not None:
                listitem.setArt({'thumb': episode['img'],
                         'icon': episode['img'],
                         'poster': episode['img'],
                         'fanart': episode['img']})
                listitem.setInfo('video', {'plot': episode['title'] + '\n' +
                                               episode['genre']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['title']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def render_csfd_series():
    # Get the list of movies from the get_csfd_tips function
    series_list = get_csfd_series()

    # Check if the list is empty
    if not series_list:
        xbmcgui.Dialog().notification("CSFD Series", "No Series found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for serie in series_list:
        if not serie['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=serie['movie'] + ' ' + serie['genre'])
            xbmcplugin.addDirectoryItem(_handle, get_url(action='episodes', what=serie['href'], serie=serie['serie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)

def episodes(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('h3', class_="film-title")
    episodes = []
    for season in main:
            serie = params['serie'] + ' '  + season.find('span', class_="film-title-info").text
            year = season.find('span', class_="info").text
            title = season.find('a').text
            info = season.find('span', class_="film-title-info").text
            href = season.find('a')['href']
            episodes.append({'title': title, 'href': href, 'info': info, 'year': year, 'serie': serie})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=episode['title'] + ' ' + episode['info'])
        if re.search(r'\(E\d+\)', episode['info']):
            xbmcplugin.addDirectoryItem(_handle,get_url(action='search', what=episode['serie']),listitem,True)
        else:
            xbmcplugin.addDirectoryItem(_handle,get_url(action='episodeinseries', what=episode['href'], year=episode['year'], serie=params['serie']),listitem,True )
    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)

def episodeinseries(params):
    # Get the list of movies from the get_csfd_tips function
    data_url = 'https://www.csfd.cz' + params['what']

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('h3', class_="film-title")
    episodes = []
    for season in main:
            serie = params['serie'] + ' '  + season.find('span', class_="film-title-info").text
            title = season.find('a').text + ' ' + params['year']
            info = season.find('span', class_="film-title-info").text
            href = season.find('a')['href']
            episodes.append({'title': title, 'href': href, 'info': info, 'serie': serie})

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Episodes", "No Episodes found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        listitem = xbmcgui.ListItem(label=episode['title'] + ' ' + episode['info'])
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['serie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)

def render_csfd_tips():
    # Get the list of movies from the get_csfd_tips function
    episodes = get_csfd_tips()

    # Check if the list is empty
    if not episodes:
        xbmcgui.Dialog().notification("CSFD Tips", "No movies found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Iterate through the list and render each movie
    for episode in episodes:
        if not episode['isadult'] or int(_addon.getSetting('scategory')) == 6:
            listitem = xbmcgui.ListItem(label=episode['movie'] )
            if episode['img'] is not None:
                listitem.setArt({'thumb': episode['img'],
                                 'icon': episode['img'],
                                 'poster': episode['img'],
                                 'fanart': episode['img']})
            listitem.setInfo('video', {'plot': episode['movie'] + '\n' +
                                               episode['genre']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=episode['movie']), listitem, True)

    # End the directory to display the items
    xbmcplugin.endOfDirectory(_handle)


def queue(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30202))
    token = revalidate()
    updateListing=False
    
    if 'dequeue' in params:
        response = api('dequeue_file',{'ident':params['dequeue'],'wst':token})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            popinfo(_addon.getLocalizedString(30106))
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        updateListing=True
    
    response = api('queue',{'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file)
            commands = []
            commands.append(( _addon.getLocalizedString(30215), 'Container.Update(' + get_url(action='queue',dequeue=item['ident']) + ')'))
            listitem = tolistitem(item,commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)

def toqueue(ident,token):
    response = api('queue_file',{'ident':ident,'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        popinfo(_addon.getLocalizedString(30105))
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)


def history(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30203))
    token = revalidate()
    updateListing=False
    
    if 'remove' in params:
        remove = params['remove']
        updateListing=True
        response = api('history',{'wst':token})
        xml = ET.fromstring(response.content)
        ids = []
        if is_ok(xml):
            for file in xml.iter('file'):
                if remove == file.find('ident').text:
                    ids.append(file.find('download_id').text)
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        if ids:
            rr = api('clear_history',{'ids[]':ids,'wst':token})
            xml = ET.fromstring(rr.content)
            if is_ok(xml):
                popinfo(_addon.getLocalizedString(30104))
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    response = api('history',{'wst':token})
    xml = ET.fromstring(response.content)
    files = []
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file, ['ended_at', 'download_id', 'started_at'])
            if item not in files:
                files.append(item)
        for file in files:
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history',remove=file['ident']) + ')'))
            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history',toqueue=file['ident']) + ')'))
            listitem = tolistitem(file, commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=file['ident'],name=file['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)
    
def settings(params):
    _addon.openSettings()
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def infonize(data,key,process=str,showkey=True,prefix='',suffix='\n'):
    if key in data:
        return prefix + (key.capitalize() + ': ' if showkey else '') + process(data[key]) + suffix
    return ''

def fpsize(fps):
    x = round(float(fps),3)
    if int(x) == x:
       return str(int(x))
    return str(x)

def seconds_to_hms(seconds):
    return time.strftime('%H:%M:%S', time.gmtime(int(seconds)))

def estimate_video_quality(info):
    width = int(info.get('width', 0))
    height = int(info.get('height', 0))
    bitrate = int(info.get('bitrate', 0))
    if width >= 3840 or height >= 2160 and bitrate > 10000000:
        return "Ultra High (4K)"
    elif width >= 1920 or height >= 1080 and bitrate > 4000000:
        return "High (1080p+)"
    elif width >= 1280 or height >= 720 and bitrate > 2000000:
        return "Medium (720p)"
    elif width > 0 and height > 0:
        return "Low (SD)"
    else:
        return "Unknown"

def getinfo(ident,wst):
    response = api('file_info',{'ident':ident,'wst': wst})
    xml = ET.fromstring(response.content)
    ok = is_ok(xml)
    if not ok:
        response = api('file_info',{'ident':ident,'wst': wst, 'maybe_removed':'true'})
        xml = ET.fromstring(response.content)
        ok = is_ok(xml)
    if ok:
        return xml
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None

def info(params):
    token = revalidate()
    xml = getinfo(params['ident'],token)
    
    if xml is not None:
        info = todict(xml)
        text = ''
        text += infonize(info, 'name')
        text += infonize(info, 'size', sizelize)
        text += infonize(info, 'type')
        text += 'Quality: ' + estimate_video_quality(info) + '\n'
        text += infonize(info, 'length', seconds_to_hms)
        text += infonize(info, 'format')
        text += infonize(info, 'bitrate', lambda x:sizelize(x,['bps','Kbps','Mbps','Gbps']))
        #xbmcgui.Dialog().textviewer(_addon.getAddonInfo('name'), text)
        return text

def getlink(ident,wst,dtype='video_stream'):
    #uuid experiment
    duuid = _addon.getSetting('duuid')
    if not duuid:
        duuid = str(uuid.uuid4())
        _addon.setSetting('duuid',duuid)
    data = {'ident':ident,'wst': wst,'download_type':dtype,'device_uuid':duuid}
    #TODO password protect
    #response = api('file_protected',data) #protected
    #xml = ET.fromstring(response.content)
    #if is_ok(xml) and xml.find('protected').text != 0:
    #    pass #ask for password
    response = api('file_link',data)
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return xml.find('link').text
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None


class Url(str):
    def __init__(self, url_path):
        super(Url, self).__init__()
        self.url = url_path if url_path.startswith('http') else '{protocol}:{path}'.format(protocol="https", path=url_path)

    def __repr__(self):
        return repr(self.url)

    def __str__(self):
        return self.url

    def __call__(self, *args, **kwargs):
        return self.url

    def __add__(self, str2):
        return self.url + str2

def request(method, url, timeout=20, **kwargs):
        return requests.request(
            method=method,
            url=Url(url)(),
            timeout=timeout,
            **kwargs
        )

def get(url, **kwargs):
            return request(HTTP_METHOD.GET, url, **kwargs)

def get_csfd_tips():
    """Get daily tips from CSFD site."""
    data_url = CSFD_TIPS

    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article")
    #return [f"{elem.find('a').text} {elem.find('span', class_='info').text}" for elem in main]
    return [
        {   "img": None if elem.find('img', class_='empty-image')  else 'https:' + elem.find('img')['src'],
            "movie": f"{elem.find('a', class_='film-title-name').text} {elem.find('span', class_='info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
            }
        for elem in main
    ]

def get_csfd_movies():
    """Get daily tips from CSFD site."""
    data_url = CSFD_SEARCH_MOVIE
    search_value = ask('')
    if search_value is None:
       return

    result = get(data_url.format(movie_name=search_value), headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('article', class_="article")
    #return [f"{elem.find('a').text} {elem.find('span', class_='info').text} {elem.find('p', class_='film-origins-genres').find('span', class_='info').text}" for elem in main]
    return [
        {   "img": None if elem.find('img', class_='empty-image')  else 'https:' + elem.find('img')['src'],
            "movie": f"{elem.find('a', class_='film-title-name').text} {elem.find('span', class_='info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        }
        for elem in main
    ]

def get_csfd_series():
    """Get daily tips from CSFD site."""
    data_url = CSFD_SEARCH_SERIES
    search_value = ask('')

    result = get(data_url.format(series_name=search_value), headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('div', class_="article-content")
    #return [f"{elem.find('a').text} {elem.find('span', class_='info').text} {elem.find('p', class_='film-origins-genres').find('span', class_='info').text}" for elem in main]
    return [
        {
            "href": elem.find('a')['href'],
            "serie": elem.find('p', class_="search-name").text if elem.find('p', class_="search-name") else elem.find('a').text,
            "movie": f"{elem.find('a').text} {elem.find('span', class_='film-title-info').text}",
            "genre": elem.find('p', class_='film-origins-genres').find('span', class_='info').text,
            "isadult": True if 'Pornografický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text or 'Erotický' in elem.find('p', class_='film-origins-genres').find('span', class_='info').text else False
        }
        for elem in main
        if elem.find('span', class_='film-title-info') and '(seriál)' in elem.find('span', class_='film-title-info').text
    ]


def get_csfd_genres():
    """Get daily tips from CSFD site."""
    data_url = CSFD_GENRES


    result = get(data_url, headers=headers, timeout=20)
    soup = BeautifulSoup(result.content, 'html.parser')
    main = soup.find_all('div', id="item-content")
    return [option.find('label')['span'] for option in main]


def play(params):
    token = revalidate()
    link = getlink(params['ident'],token)
    if link is not None:
        #headers experiment
        headers = _session.headers
        if headers:
            headers.update({'Cookie':'wst='+token})
            link = link + '|' + urlencode(headers)
        listitem = xbmcgui.ListItem(label=params['name'],path=link)
        listitem.setProperty('mimetype', 'application/octet-stream')
        xbmcplugin.setResolvedUrl(_handle, True, listitem)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def join(path, file):
    if path.endswith('/') or path.endswith('\\'):
        return path + file
    else:
        return path + '/' + file

def download(params):
    token = revalidate()
    where = _addon.getSetting('dfolder')
    if not where or not xbmcvfs.exists(where):
        popinfo('set folder!', sound=True)#_addon.getLocalizedString(30101)
        _addon.openSettings()
        return
        
    local = os.path.exists(where)
        
    normalize = 'true' == _addon.getSetting('dnormalize')
    notify = 'true' == _addon.getSetting('dnotify')
    every = _addon.getSetting('dnevery')
    try:
        every = int(re.sub(r'[^\d]+', '', every))
    except:
        every = 10
        
    try:
        link = getlink(params['ident'],token,'file_download')
        info = getinfo(params['ident'],token)
        name = info.find('name').text
        if normalize:
            name = unidecode.unidecode(name)
        bf = io.open(os.path.join(where,name), 'wb') if local else xbmcvfs.File(join(where,name), 'w')
        response = _session.get(link, stream=True)
        total = response.headers.get('content-length')
        if total is None:
            popinfo(_addon.getLocalizedString(30301) + name, icon=xbmcgui.NOTIFICATION_WARNING, sound=True)
            bf.write(response.content)
        elif not notify:
            popinfo(_addon.getLocalizedString(30302) + name)
            bf.write(response.content)
        else:
            popinfo(_addon.getLocalizedString(30302) + name)
            dl = 0
            total = int(total)
            pct = total / 100
            lastpop=0
            for data in response.iter_content(chunk_size=4096):
                dl += len(data)
                bf.write(data)
                done = int(dl / pct)
                if done % every == 0 and lastpop != done:
                    popinfo(str(done) + '% - ' + name)
                    lastpop = done
        bf.close()
        popinfo(_addon.getLocalizedString(30303) + name, sound=True)
    except Exception as e:
        #TODO - remove unfinished file?
        traceback.print_exc()
        popinfo(_addon.getLocalizedString(30304) + name, icon=xbmcgui.NOTIFICATION_ERROR, sound=True)

def loaddb(dbdir,file):
    try:
        data = {}
        with io.open(os.path.join(dbdir, file), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                data = json.loads(fdata, "utf-8")['data']
            except TypeError:
                data = json.loads(fdata)['data']
        return data
    except Exception as e:
        traceback.print_exc()
        return {}

def db(params):
    token = revalidate()
    updateListing=False

    dbdir = os.path.join(_profile,'db')
    if not os.path.exists(dbdir):
        link = getlink(BACKUP_DB,token)
        dbfile = os.path.join(_profile,'db.zip')
        with io.open(dbfile, 'wb') as bf:
            response = _session.get(link, stream=True)
            bf.write(response.content)
            bf.flush()
            bf.close()
        with zipfile.ZipFile(dbfile, 'r') as zf:
            zf.extractall(_profile)
        os.unlink(dbfile)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    if 'file' in params and 'key' in params:
        data = loaddb(dbdir,params['file'])
        item = next((x for x in data if x['id'] == params['key']), None)
        if item is not None:
            for stream in item['streams']:
                commands = []
                commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='db',file=params['file'],key=params['key'],toqueue=stream['ident']) + ')'))
                listitem = tolistitem({'ident':stream['ident'],'name':stream['quality'] + ' - ' + stream['lang'] + stream['ainfo'],'sizelized':stream['size']},commands)
                xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=stream['ident'],name=item['title']), listitem, False)
    elif 'file' in params:
        data = loaddb(dbdir,params['file'])
        for item in data:
            listitem = xbmcgui.ListItem(label=item['title'])
            if 'plot' in item:
                listitem.setInfo('video', {'title': item['title'],'plot': item['plot']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=params['file'],key=item['id']), listitem, True)
    else:
        if os.path.exists(dbdir):
            dbfiles = [f for f in os.listdir(dbdir) if os.path.isfile(os.path.join(dbdir, f))]
            for dbfile in dbfiles:
                listitem = xbmcgui.ListItem(label=os.path.splitext(dbfile)[0])
                xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=dbfile), listitem, True)
    xbmcplugin.addSortMethod(_handle,xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def menu():
    revalidate()
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30201))
    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), listitem, True)
    
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30202))
    listitem.setArt({'icon': 'DefaultPlaylist.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='queue'), listitem, True)

    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30305))
    listitem.setArt({'icon': 'DefaultPlaylist.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='CSFD'), listitem, True)

    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30307))
    listitem.setArt({'icon': 'DefaultPlaylist.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='Movies'), listitem, True)

    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30308))
    listitem.setArt({'icon': 'DefaultPlaylist.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='Series'), listitem, True)

    
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30203))
    listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)
    
    if 'true' == _addon.getSetting('experimental'):
        listitem = xbmcgui.ListItem(label='Backup DB')
        listitem.setArt({'icon': 'DefaultAddonsZip.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='db'), listitem, True)

    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30204))
    listitem.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

    xbmcplugin.endOfDirectory(_handle)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'search':
            search(params)
        elif params['action'] == 'queue':
            queue(params)
        elif params['action'] == 'CSFD':
            render_csfd_tips()
        elif params['action'] == 'Genres':
            render_csfd_genres()
        elif params['action'] == 'Movies':
            render_movie_section()
        elif params['action'] == 'Series':
            render_csfd_series()
        elif params['action'] == 'history':
            history(params)
        elif params['action'] == 'settings':
            settings(params)
        elif params['action'] == 'info':
            info(params)
        elif params['action'] == 'play':
            play(params)
        elif params['action'] == 'episodes':
            episodes(params)
        elif params['action'] == 'episodeinseries':
            episodeinseries(params)
        elif params['action'] == 'render_rank_movies':
            render_rank_movies()
        elif params['action'] == 'get_rank_movies':
            get_rank_movies(params)
        elif params['action'] == 'render_csfd_movies':
            render_csfd_movies()
        elif params['action'] == 'download':
            download(params)
        elif params['action'] == 'db':
            db(params)
        else:
            menu()
    else:
        menu()
